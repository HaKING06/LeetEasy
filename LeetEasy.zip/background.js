chrome.commands.onCommand.addListener((command) => {
    if (command === "toggle-panel") {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, { type: "PANEL_TOGGLE" });
            }
        });
    }
});
// background.js - SESSİZ SEKME YÖNETİCİSİ
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === "OPEN_BG_TAB") {
        chrome.tabs.create({ 
            url: request.url, 
            active: false // ÖNEMLİ: Sekmeyi açar ama odaklanmaz
        });
    }
});