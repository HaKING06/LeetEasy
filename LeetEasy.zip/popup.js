const els = {
    // Üst Panel Butonları
    scanBtn: document.getElementById('scanBtn'),
    saveBtn: document.getElementById('saveBtn'),
    status: document.getElementById('status'),
    
    // Ayar Girdileri
    speed: document.getElementById('speed'),
    hotkey: document.getElementById('hotkey'),
    macro: document.getElementById('macroSwitch'),
    chaos: document.getElementById('chaosSwitch'),
    mimic: document.getElementById('mimicSwitch'), // Gölge Taklitçi (Geri Geldi)
    target: document.getElementById('targetUser'),
    
    // Bot Paneli Butonları
    btnMaster: document.getElementById('btnMaster'),
    btnSlave: document.getElementById('btnSlave'),

    // Fabrika Elemanları Bot
    botCount: document.getElementById('botCount'),
    btnStartFactory: document.getElementById('btnStartFactory'),

    // Kütüphane & Filtre
    searchBox: document.getElementById('searchBox'),
    listContainer: document.getElementById('listContainer'),
    filterBtns: document.querySelectorAll('.f-btn')

    
};

// =========================================================
// 1. AÇILIŞTA AYARLARI YÜKLE
// =========================================================
document.addEventListener('DOMContentLoaded', () => {
    // Bot durumunu çekmiyoruz, çünkü butonlar anlık çalışacak (Stateless)
    chrome.storage.local.get(['hiz', 'tus', 'master', 'chaos', 'target', 'mimic'], (d) => {
        if(d.hiz) els.speed.value = d.hiz;
        if(d.tus) els.hotkey.value = d.tus;
        
        // Checkbox Durumları
        els.macro.checked = d.master === true;
        els.chaos.checked = d.chaos === true;
        els.mimic.checked = d.mimic === true; 
        
        // Hedef Listesi
        if(d.target) {
            const o = document.createElement('option');
            o.value = d.target; o.text = d.target; o.selected = true;
            els.target.appendChild(o);
        }
    });
    
    // Kütüphaneyi listele
    renderList("");
});

// =========================================================
// 2. BOT BUTONLARI (UZAKTAN KUMANDA MANTIĞI)
// =========================================================
// Bu butonlar ayar kaydetmez, direkt o anki sekmeye emir yollar.

// KOMUTAN OL (F2)
els.btnMaster.onclick = () => {
    sendCommand("YAP_KOMUTAN");
    showTempStatus("👑 Komut: KOMUTAN MODU!");
};

// TAKİPÇİ OL (F4)
els.btnSlave.onclick = () => {
    sendCommand("YAP_KOLE");
    showTempStatus("🔗 Komut: TAKİPÇİ MODU!");
};

// Yardımcı: Emri Aktif Sekmeye Gönder
function sendCommand(actionType) {
    chrome.tabs.query({active: true, currentWindow: true}, tabs => {
        if(tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, { type: actionType });
        }
    });
}

// Yardımcı: Geçici Durum Mesajı Göster
function showTempStatus(msg) {
    const originalText = els.status.innerText;
    els.status.innerText = msg;
    els.status.style.color = "#000"; // Siyah yap okunsun
    setTimeout(() => {
        els.status.innerText = "Sistem hazır.";
        els.status.style.color = "#555";
    }, 1500);
}

// =========================================================
// 3. GENEL AYARLARI KAYDET
// =========================================================
els.saveBtn.onclick = () => {
    const config = {
        hiz: els.speed.value, 
        tus: els.hotkey.value.toUpperCase(),
        master: els.macro.checked,
        chaos: els.chaos.checked,
        mimic: els.mimic.checked, // Gölge Taklitçi verisi
        target: els.target.value
    };
    
    chrome.storage.local.set(config, () => {
        // Açık olan sekmeye ayarları canlı gönder
        chrome.tabs.query({active: true, currentWindow: true}, tabs => {
            if(tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: "AYAR_GUNCELLE", config: config });
        });
        
        els.status.innerText = "KAYDEDİLDİ!";
        els.status.style.color = "green";
        setTimeout(() => {
            els.status.innerText = "Hazır.";
            els.status.style.color = "#555";
        }, 1500);
    });
};

// =========================================================
// 4. HEDEF TARAMA (ODAYI TARA)
// =========================================================
els.scanBtn.onclick = () => {
    els.status.innerText = "Taranıyor...";
    chrome.tabs.query({active: true, currentWindow: true}, tabs => {
        if(tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: "ODAYI_TARA" }, res => {
            if (res && res.users) {
                // Listeyi temizle ve yeniden doldur
                els.target.innerHTML = '<option value="">-- Hedef Seç --</option>';
                res.users.forEach(u => {
                    const o = document.createElement('option');
                    o.value = u; o.text = u; els.target.appendChild(o);
                });
                els.status.innerText = `${res.users.length} kişi bulundu.`;
            } else {
                els.status.innerText = "Kimse bulunamadı.";
            }
        });
    });
};

// =========================================================
// 5. SEKME (TAB) GEÇİŞLERİ
// =========================================================
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.onclick = () => {
        // Hepsinden active sil
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        
        // Tıklanana active ekle
        btn.classList.add('active');
        document.getElementById(btn.dataset.tab).classList.add('active');
    };
});

// =========================================================
// 6. KÜTÜPHANE & LİSTELEME
// =========================================================
let activeFilter = "all";

// Filtre Butonları
els.filterBtns.forEach(btn => {
    btn.onclick = () => {
        els.filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeFilter = btn.dataset.filter;
        renderList(els.searchBox.value);
    }
});

// Arama Kutusu
els.searchBox.oninput = (e) => renderList(e.target.value);

function renderList(s) {
    els.listContainer.innerHTML = "";
    s = s.toLowerCase();
    
    // KOMUTLAR (data.js dosyasından gelir)
    if (activeFilter === "all" || activeFilter === "komut") {
        if(typeof COMMANDS !== 'undefined') COMMANDS.forEach(cmd => {
            if (cmd.code.includes(s) || cmd.desc.toLowerCase().includes(s)) {
                createItem(cmd.code, cmd.desc, "KOMUT", { code: cmd.code, needTarget: cmd.needTarget });
            }
        });
    }

    // EŞYALAR (data.js dosyasından gelir)
    if (activeFilter !== "komut") {
        if(typeof ITEMS !== 'undefined') ITEMS.forEach(item => {
            if (activeFilter === "all" || item.type === activeFilter) {
                if (item.name.toLowerCase().includes(s)) {
                    let code = "";
                    let badge = "";
                    if (item.type === 'icecekk') { code = `:içecek ${item.id}`; badge = "EŞYA"; } 
                    else if (item.type === 'icecek') { code = `:içecek ${item.id}`; badge = "İÇECEK"; }
                    else if (item.type === 'efekt') { code = `:efekt ${item.id}`; badge = "EFEKT"; }
                    else if (item.type === 'pet') { code = `:pet ${item.id}`; badge = "HAYVAN"; } // BURASI EKLENDİ
                    createItem(item.name, `#${item.id}`, badge, { code: code });
                }
            }
        });
    }
}

// Liste Elemanı Oluşturucu
// Liste Elemanı Oluşturucu (GÜNCELLENMİŞ HALİ)
function createItem(title, desc, badge, data) {
    const div = document.createElement('div');
    div.className = 'list-item';
    div.innerHTML = `
        <div>
            <span style="font-weight:bold;color:#000;">${title}</span> 
            <span style="font-size:10px;color:#555;">${desc}</span>
        </div>
        <div class="item-badge">${badge}</div>
    `;

    // --- YENİ TIKLAMA MANTIĞI ---
    div.onclick = () => {
        let finalCode = data.code;

        // Eğer komut bir hedef gerektiriyorsa (Örn: :çek)
        if (data.needTarget) {
            const targetName = els.target.value; // Yukarıdaki listeden seçili ismi al
            
            if (targetName && targetName !== "") {
                finalCode += " " + targetName; // İsmi komuta ekle (Örn: :çek Ahmet)
            } else {
                // Kimse seçili değilse uyar
                alert("⚠ Bu komut için yukarıdan bir HEDEF (Kullanıcı) seçmelisin!");
                return; // Gönderme işlemini iptal et
            }
        }
        
        sendToGame(finalCode);
    };
    // ----------------------------

    els.listContainer.appendChild(div);
}

// Oyuna Komut Gönder
function sendToGame(text) {
    navigator.clipboard.writeText(text); // Panoya kopyala
    chrome.tabs.query({active: true, currentWindow: true}, tabs => {
        if(tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: "KOMUT_GONDER", text: text });
    });
    showTempStatus("Gönderildi!");
}

// --- popup.js (EN ALTA EKLE) ---

els.botCount = document.getElementById('botCount');
els.btnStartFactory = document.getElementById('btnStartFactory');

if(els.btnStartFactory) {
    els.btnStartFactory.onclick = () => {
        let count = parseInt(els.botCount.value);
        if (count < 1) count = 1;
        if (count > 20) count = 20;

        const factorySettings = {
            factoryOn: true,
            factoryTarget: count,
            factoryCurrent: 0
        };

        chrome.storage.local.set(factorySettings, () => {
            // Temiz başlangıç için önce çıkış yapıyoruz
            chrome.tabs.create({ url: "https://www.leethotel.biz/logout" });
            window.close();
        });
    };
}



// --- popup.js'nin EN ALTINA EKLE ---

const btnSummon = document.getElementById('btnSummon');

if(btnSummon) {
    btnSummon.onclick = () => {
        // 1. Aktif sekmeye (Sana) sor: "Hangi odadasın?"
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            if(tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, { type: "ODA_ISMI_VER" }, (response) => {
                    if (response && response.roomName) {
                        const room = response.roomName;
                        // 2. Tüm sekmelere (Kölelere) emir ver: "Bu odaya gelin"
                        chrome.tabs.query({}, (allTabs) => {
                            allTabs.forEach(t => {
                                chrome.tabs.sendMessage(t.id, { type: "GIT_ODAYA", roomName: room }).catch(e=>{});
                            });
                        });
                        alert("Köleler çağırılıyor: " + room);
                    } else {
                        alert("Oda ismi bulunamadı! Lütfen bir odada olduğundan emin ol.");
                    }
                });
            }
        });
    };
}