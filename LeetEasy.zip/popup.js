const els = {
    scanBtn: document.getElementById('scanBtn'),
    saveBtn: document.getElementById('saveBtn'),
    status: document.getElementById('status'),
    speed: document.getElementById('speed'),
    hotkey: document.getElementById('hotkey'),
    master: document.getElementById('masterSwitch'),
    mimic: document.getElementById('mimicSwitch'),
    chaos: document.getElementById('chaosSwitch'),
    target: document.getElementById('targetUser'),
    // Kütüphane
    searchBox: document.getElementById('searchBox'),
    listContainer: document.getElementById('listContainer'),
    filterBtns: document.querySelectorAll('.f-btn')
};

// YÜKLEME
document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.local.get(['hiz', 'tus', 'master', 'mimic', 'target', 'chaos'], (d) => {
        if(d.hiz) els.speed.value = d.hiz;
        if(d.tus) els.hotkey.value = d.tus;
        els.master.checked = d.master === true;
        els.mimic.checked = d.mimic === true;
        els.chaos.checked = d.chaos === true;
        if(d.target) {
            const o = document.createElement('option');
            o.value = d.target; o.text = d.target; o.selected = true;
            els.target.appendChild(o);
        }
    });
    renderList("");
});

// KAYDET
els.saveBtn.onclick = () => {
    const config = {
        hiz: els.speed.value, tus: els.hotkey.value.toUpperCase(),
        master: els.master.checked, mimic: els.mimic.checked,
        target: els.target.value, chaos: els.chaos.checked
    };
    chrome.storage.local.set(config, () => {
        chrome.tabs.query({active: true, currentWindow: true}, tabs => {
            if(tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: "AYAR_GUNCELLE", config: config });
        });
        els.status.innerText = "KAYDEDİLDİ!";
        setTimeout(() => els.status.innerText = "Hazır.", 1000);
    });
};

// ODA TARA (KAPSAMLI)
els.scanBtn.onclick = () => {
    els.status.innerText = "Taranıyor...";
    chrome.tabs.query({active: true, currentWindow: true}, tabs => {
        if(tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: "ODAYI_TARA" }, res => {
            if (res && res.users) {
                els.target.innerHTML = '<option value="">-- Seç --</option>';
                res.users.forEach(u => {
                    const o = document.createElement('option');
                    o.value = u; o.text = u; els.target.appendChild(o);
                });
                els.status.innerText = `${res.users.length} kişi bulundu.`;
            } else {
                els.status.innerText = "Kimse bulunamadı.";
            }
        });
    });
};

// TAB GEÇİŞ
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.onclick = () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.dataset.tab).classList.add('active');
    };
});

// FİLTRE BUTONLARI
let activeFilter = "all";
els.filterBtns.forEach(btn => {
    btn.onclick = () => {
        els.filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeFilter = btn.dataset.filter;
        renderList(els.searchBox.value);
    }
});

els.searchBox.oninput = (e) => renderList(e.target.value);

// LİSTELEME MOTORU
function renderList(s) {
    els.listContainer.innerHTML = "";
    s = s.toLowerCase();
    
    // KOMUTLAR
    if (activeFilter === "all" || activeFilter === "komut") {
        if(typeof COMMANDS !== 'undefined') COMMANDS.forEach(cmd => {
            if (cmd.code.includes(s) || cmd.desc.toLowerCase().includes(s)) {
                createItem(cmd.code, cmd.desc, "KOMUT", { code: cmd.code });
            }
        });
    }

    // EŞYALAR
    if (activeFilter !== "komut") {
        if(typeof ITEMS !== 'undefined') ITEMS.forEach(item => {
            if (activeFilter === "all" || item.type === activeFilter) {
                if (item.name.toLowerCase().includes(s)) {
                    let code = "";
                    let badge = "";
                    
                    if (item.type === 'icecekk') { code = `:içecek ${item.id}`; badge = "EŞYA"; } 
                    else if (item.type === 'icecek') { code = `:içecek ${item.id}`; badge = "İÇECEK"; }
                    else if (item.type === 'efekt') { code = `:efekt ${item.id}`; badge = "EFEKT"; }

                    createItem(item.name, `#${item.id}`, badge, { code: code });
                }
            }
        });
    }
}

function createItem(title, desc, badge, data) {
    const div = document.createElement('div');
    div.className = 'list-item';
    div.innerHTML = `
        <div><span style="font-weight:bold; color:#000;">${title}</span> <span style="font-size:10px;color:#555;">${desc}</span></div>
        <div class="item-badge">${badge}</div>
    `;
    div.onclick = () => sendToGame(data.code);
    els.listContainer.appendChild(div);
}

function sendToGame(text) {
    navigator.clipboard.writeText(text);
    chrome.tabs.query({active: true, currentWindow: true}, tabs => {
        if(tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: "KOMUT_GONDER", text: text });
    });
    els.status.innerText = "Gönderildi: " + text;
}