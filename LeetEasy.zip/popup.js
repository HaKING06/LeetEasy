const saveBtn = document.getElementById('saveBtn');
const scanBtn = document.getElementById('scanBtn');
const statusText = document.getElementById('status');
const searchBox = document.getElementById('searchBox');
const listContainer = document.getElementById('listContainer');
const tabs = document.querySelectorAll('.tab-btn');
const filters = document.querySelectorAll('.filter-btn');

const els = {
    speed: document.getElementById('speed'),
    hotkey: document.getElementById('hotkey'),
    masterSwitch: document.getElementById('masterSwitch'),
    mimicSwitch: document.getElementById('mimicSwitch'),
    targetUser: document.getElementById('targetUser')
};

let activeFilter = "all";

document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.local.get(['hiz', 'tus', 'sistemAcik', 'mimicAcik', 'hedefKisi'], (d) => {
        if(d.hiz) els.speed.value = d.hiz;
        if(d.tus) els.hotkey.value = d.tus;
        els.masterSwitch.checked = d.sistemAcik === true;
        els.mimicSwitch.checked = d.mimicAcik === true;
        if(d.hedefKisi) {
            const o = document.createElement('option');
            o.value = d.hedefKisi; o.text = d.hedefKisi; o.selected = true;
            els.targetUser.appendChild(o);
        }
    });
    renderList("");
});

function renderList(s) {
    listContainer.innerHTML = "";
    s = s.toLowerCase();

    if (activeFilter === "all" || activeFilter === "komut") {
        COMMANDS.forEach(cmd => {
            if (cmd.code.includes(s) || cmd.desc.toLowerCase().includes(s)) {
                addItem(cmd.code, cmd.desc, "KOMUT", cmd);
            }
        });
    }

    if (activeFilter !== "komut") {
        ITEMS.forEach(item => {
            if (activeFilter === "all" || item.type === activeFilter) {
                if (item.name.toLowerCase().includes(s)) {
                    let code = "";
                    if (item.type === 'icecek') code = `:içecek ${item.id}`;
                    if (item.type === 'efekt') code = `:efekt ${item.id}`;
                    if (item.type === 'el') code = `:el ${item.id}`;
                    addItem(item.name, item.type.toUpperCase(), item.id, { code: code });
                }
            }
        });
    }
}

function addItem(title, desc, badge, data) {
    const div = document.createElement('div');
    div.className = 'list-item';
    div.innerHTML = `<div><span class="item-code">${title}</span> <span style="color:#555;font-size:10px;">${desc}</span></div><div class="item-type">${badge}</div>`;
    div.onclick = () => {
        let final = data.code;
        if (data.needTarget) {
            const target = els.targetUser.value;
            if (target) final += " " + target;
            else {
                const manual = prompt("Kullanıcı adı:");
                if (!manual) return;
                final += " " + manual;
            }
        }
        send(final);
    };
    listContainer.appendChild(div);
}

// Sekmeler
tabs.forEach(b => b.onclick = () => {
    document.querySelectorAll('.tab-btn').forEach(x => x.classList.remove('active'));
    document.querySelectorAll('.page').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    document.getElementById(b.dataset.tab).classList.add('active');
});

// Filtreler
filters.forEach(b => b.onclick = () => {
    filters.forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    activeFilter = b.dataset.filter;
    renderList(searchBox.value);
});

searchBox.oninput = (e) => renderList(e.target.value);

// Kaydet
saveBtn.onclick = () => {
    const cfg = {
        hiz: els.speed.value, tus: els.hotkey.value.toUpperCase(),
        sistemAcik: els.masterSwitch.checked, mimicAcik: els.mimicSwitch.checked,
        hedefKisi: els.targetUser.value
    };
    chrome.storage.local.set(cfg, () => {
        chrome.tabs.query({active: true, currentWindow: true}, tabs => {
            if(tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: "AYAR_GUNCELLE", config: cfg });
        });
        statusText.innerText = "KAYDEDİLDİ!";
        setTimeout(() => statusText.innerText = "Hazır.", 1000);
    });
};

// Tara
scanBtn.onclick = () => {
    statusText.innerText = "Taranıyor...";
    chrome.tabs.query({active: true, currentWindow: true}, tabs => {
        if(tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: "ODAYI_TARA" }, r => {
            if (r && r.users) {
                els.targetUser.innerHTML = '<option value="">--Seç--</option>';
                r.users.forEach(u => {
                    const o = document.createElement('option');
                    o.value = u; o.text = u; els.targetUser.appendChild(o);
                });
                statusText.innerText = `${r.users.length} kişi.`;
            }
        });
    });
};

function send(txt) {
    navigator.clipboard.writeText(txt);
    chrome.tabs.query({active: true, currentWindow: true}, tabs => {
        if(tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: "KOMUT_GONDER", text: txt });
    });
    statusText.innerText = "Gönderildi: " + txt;
}