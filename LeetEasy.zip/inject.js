// inject.js - SAYFA İÇİ ARAÇLAR

(function() {
    
    // --- 1. TIKLAMA FONKSİYONU ---
    function forceClick(element) {
        if (!element) return;
        element.click();
        var opts = { bubbles: true, cancelable: true, view: window, button: 0, buttons: 1 };
        element.dispatchEvent(new MouseEvent('mousedown', opts));
        element.dispatchEvent(new MouseEvent('mouseup', opts));
        element.dispatchEvent(new MouseEvent('click', opts));
    }

    // --- 2. ODA BULUCU ---
    window.findAndJoinRoom = function(roomName, ownerName) {
        var items = document.querySelectorAll('.navigator-item');
        for(var i=0; i<items.length; i++) {
            var item = items[i];
            var nameEl = item.querySelector('.ubuntu-leet') || item.querySelector('.room-name');
            var txt = nameEl ? nameEl.innerText.trim() : "";
            
            if(txt === roomName) {
                if (ownerName) {
                    if (item.innerText.includes(ownerName)) {
                        clickItem(item);
                        return;
                    }
                } else {
                    clickItem(item);
                    return;
                }
            }
        }
    };

    function clickItem(item) {
        item.style.border = "3px solid #00ff00"; 
        forceClick(item);
    }

    // --- 3. CAPTCHA TIKLAYICI ---
    setInterval(function() {
        var buster = document.getElementById('solver-button');
        if (buster && !buster.dataset.clicked && buster.offsetParent !== null) {
            buster.dataset.clicked = "true";
            buster.style.border = "4px solid red";
            forceClick(buster);
        }
        var anchor = document.getElementById('recaptcha-anchor');
        var box = document.querySelector('.recaptcha-checkbox');
        if (anchor && box && !box.classList.contains('recaptcha-checkbox-checked') && !anchor.dataset.clicked) {
            anchor.dataset.clicked = "true";
            forceClick(anchor);
        }
        var errorMsg = document.querySelector('.rc-audiochallenge-error-message');
        if (errorMsg && errorMsg.style.display !== 'none') {
            var reloadBtn = document.getElementById('recaptcha-reload-button');
            if (reloadBtn) forceClick(reloadBtn);
        }
    }, 800);

})();